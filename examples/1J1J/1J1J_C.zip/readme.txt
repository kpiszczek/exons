----------------------------------------------------------------------------------
ExonVisualiser results visualization using PyMOL - instruction
-------------------------------------------------- -------------------------------

For visualization, it is necessary to have installed PyMOL.
The program can be downloaded from http://http//www.pymol.org/

In addition to the readme.txt file in the archive you downloaded from 
the application (otput) are two files with the extension *. pml and *. pdb.

PDB file has not been changed, it is the same as the one sent to the application.

File with the extension *. Pml contains the commands for protein mol3ecule and exons 
localization visualisation in PyMOL.

To see the results, open the file *. pml using PyMOL.